#ifndef MF_GEN_H
#define MF_GEN_H

#include "make/declconst.h"
#include "make/print.h"
#include "make/utility.h"

class Gen
{ 
	
public:
	static void run(std::ofstream& fout);
};



#endif
