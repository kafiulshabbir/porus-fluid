#ifndef MF_FORCE_H
#define MF_FORCE_H

#include "make/print.h"

class Force
{
	
public:
	static void run(std::ofstream& fout);
};


#endif
