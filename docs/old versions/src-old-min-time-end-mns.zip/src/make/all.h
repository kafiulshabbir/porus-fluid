#ifndef MF_ALL_H
#define MF_ALL_H

#include "make/print.h"

class All
{
public:
	static void run(std::ofstream& fout);
};


#endif
