#include "math/mathlinear.h"
#include "decl/decltypedef.h"
//#include "dst/dstdiamension.h"
int main()
{
	/*
	Tfloat v
	{
		{2, -1, -1, 10}, //s12 = 10
		{-1, 2, -1, -110}, //s13 = -100
		{-1, -1, 2, 100}
	};
	*/
	Tfloat v
	{
		{1,1,2,1,1,0,1,8},
		{2,1,2,3,1,3,0,21},
		{1,-1,-1,2,4,-5,6,12},
		{1,0,2,2,0,1,3,7},
		{-1,-2,0,4,3,2,4,23},
		{0,6,5,4,3,2,1,35},
		{4,5,10,16,12,3,15,106}
	};
	

	math::Linear::gauss_elimination(v);
	
	
	// Tests for diamension
	/*
	dst::Diamension d1(2, 4);
	dst::Diamension d2(6, 4);
	
	std::cout << "total-nodes=" << d1.total_nodes() << std::endl;
	std::cout << "rows=" << d1.node_rows() << std::endl;
	std::cout << "cols0=" << d1.node_cols(0) << std::endl;
	std::cout << "cols1=" << d1.node_cols(1) << std::endl;
	
	std::cout << "total-nodes=" << d2.total_nodes() << std::endl;
	std::cout << "rows=" << d2.node_rows() << std::endl;
	std::cout << "cols0=" << d2.node_cols(0) << std::endl;
	std::cout << "cols1=" << d2.node_cols(1) << std::endl;
	
	for(int i = 0; i < d1.node_rows(); ++ i)
	{
		const int j_max = d1.node_cols(i);
		for(int j = 0; j < j_max; ++ j)
		{
			std::cout << "(" << i << ", " << j << ") " <<
				d1.linear_node_from_coordinate(i, j) <<
				":" << std::endl;
			
			const std::vector<dst::Tube> connecv =
				d1.generate_tubes_connected_to_node(i, j);
				
			for(const dst::Tube& tube: connecv)
			{
				std::cout << tube << std::endl;
			}
			
			std::cout << std::endl;
		}
	}
	
	for(int i = 0; i < 2; ++ i)
	{
		for(int j = 0; j < 4; ++ j)
		{
			const std::pair<int, int> p = 
				d1.linear_node_at_ends_of_tube(i, j);
			
			std::cout << "(" << i << ", " << j << "):"
				<< p.first << ", " << p.second << std::endl;
				
		}
	}
	*/
	
	
	
	return 0;
}
