#include "math/mathlinear.h"
typedef long double lld;

std::vector<float> math::Linear::gauss_elimination(Tfloat M)
{
	const int n = M.size();
	const int rows_from_bottom_to_skip = 1;
	for(int i = 0; i + rows_from_bottom_to_skip < n; ++ i)
	{
		std::vector<float>& eq_row = M[i];
		const float divider = eq_row[i];
		// this sets the target coefficient as 1.0000 for the equation
		for(int j = i; j <= n; ++ j)
		{
			eq_row[j] /= divider;
		}
		
		for(int j = i + 1; j < n; ++ j)
		{
			std::vector<float>& eq_target_row = M[j];
			
			const float coeff = eq_target_row[i];
			
			if(coeff == 0)
			{
				continue;
			}

			for(int k = i; k <= n; ++ k)
			{
				eq_target_row[k] -= eq_row[k] * coeff;
			}
		}
		

	}
	
	for(int i = n - 2; i > 0; -- i)
	{
		const float deleter = M[i].back();
		
		for(int j = 0; j < i; ++ j)
		{
			M[j].back() -= M[j][i] * deleter;
		}
	}
	
	std::vector<float> v;

	for(auto& row: M)
	{
		v.push_back(row.back());
	}
	
	return v;
}

/*
	std::string num = std::to_string(i);
	std::string s = "gauss-for row=" + num;
	cmdio::Print::pmat(s, M);
*/
