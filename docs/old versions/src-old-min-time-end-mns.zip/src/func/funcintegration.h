#ifndef FUNCINTEGRATION_H
#define FUNCINTEGRATION_H

#include "decl/decltypedef.h"
#include "dst/dstdiamension.h"
#include <algorithm>

namespace func
{
	struct Fluid
	{
		float blue = 0;
		float grey = 0;
	};
	
	struct FluidDisplacements
	{
		Fluid in;
		Fluid out;
	};
	
	struct IntegrationResult
	{
		TMns mnsc;
		FluidDisplacements fluid_displacements;
	};
	
	
	class Integration
	{
		typedef std::vector<std::vector<Fluid>> TFluid;
		
		struct TFluidAndDisplacement
		{
			TFluid table_fluid_additions;
			FluidDisplacements fluid_displacements;
		};
		
		struct Tube_FromNode
		{
			float rad;
			int row;
			int col;
		};
		
		class Tank
		{
			Fluid fluid;
			bool blue_present = false;
			bool grey_present = false;
			
		public:
			void add_fluid(const bool type_fluid, const float vol);
			Fluid pour_out_fluid(const float vol);
		};
		
		static TFluidAndDisplacement calculate_fluid_table_and_displacements
		(
			const Tfloat& radius,
			const TMns& mnsc,
			const Tfloat& velocity,
			const Tfloat& volume,
			const dst::Diamension& diamension
		);
		
		static Fluid add_fluid_from_tank(const float vol, Fluid& tank);
		
		static bool compare_where_wetting_fluid_go_first
		(
			const Tube_FromNode& first,
			const Tube_FromNode& second
		);
		
		static TMns combine_fluid_additions
		(
			const Tfloat& radius,
			TMns mnsc,
			const Tfloat& velocity,
			const dst::Diamension& diamension,
			const TFluid& fluid_addition_table,
			const int row_mimimum_time,
			const int col_minimum_time
		);
		
		static TMns trimmer(TMns mnsc, const Tfloat& velocity);
		
	public:
		static func::IntegrationResult integrate
		(
			const Tfloat& radius,
			const TMns& mnsc,
			const Tfloat& velocity,
			const Tfloat& volume,
			const dst::Diamension& diamension,
			const int row_mimimum_time,
			const int col_minimum_time
		);
		
	};
}

#endif
