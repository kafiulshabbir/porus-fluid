#include "func/funcintegration.h"

func::IntegrationResult func::Integration::integrate
(
	const Tfloat& radius,
	const TMns& mnsc,
	const Tfloat& velocity,
	const Tfloat& volume,
	const dst::Diamension& diamension,
	const int row_minimum_time,
	const int col_minimum_time
)
{
	const TFluidAndDisplacement fluid_addition =
		calculate_fluid_table_and_displacements(radius,
		mnsc, velocity, volume, diamension);
		
	const TMns new_mnsc = combine_fluid_additions
	(
		radius,
		mnsc,
		velocity,
		diamension,
		fluid_addition.table_fluid_additions,
		row_minimum_time,
		col_minimum_time
	);
	
	const func::IntegrationResult integration_result
	{
		new_mnsc,
		fluid_addition.fluid_displacements
	};
	
	return integration_result;
}

func::Integration::TFluidAndDisplacement func::Integration::calculate_fluid_table_and_displacements
(
	const Tfloat& radius,
	const TMns& mnsc,
	const Tfloat& velocity,
	const Tfloat& volume,
	const dst::Diamension& diamension
)
{
	TFluid fluid_addition_table = diamension.empty_table_templated<Fluid>();
	FluidDisplacements fluid_displacements;
	
	for(int row = 0; row < diamension.node_rows(); ++ row)
	{
		for(int col = 0; col < diamension.node_cols(row); ++ col)
		{
			Tank tank; //vol fluid from tube into node
			std::vector<Tube_FromNode> tubes_from_node_vec;
			
			const std::vector<dst::Tube> tubes_connected_vec =
				diamension.generate_tubes_connected_to_node(row, col);
				
			const int total_directions = tubes_connected_vec.size();
			for(int direction = 0; direction < total_directions; ++ direction)
			{
				const dst::Tube& connection = tubes_connected_vec[direction];
				if(connection.active)
				{
					const float rad = radius[connection.row][connection.col];
					const dst::Mns& mns = mnsc[connection.row][connection.col];
					const float vel = velocity[connection.row][connection.col];
					const float vol = volume[connection.row][connection.col];
					
					
					if(mns.is_the_flow_from_tube_into_node(direction, vel))
					{
						const int type_fluid = mns.type_fluid_into_node(direction);
						tank.add_fluid(type_fluid, vol);
						continue;
					}

					Tube_FromNode tube
					{
						rad,
						connection.row,
						connection.col
					};
		
					tubes_from_node_vec.push_back(tube);
				}
			}
			
			//for(const auto& tpshin: tubes_from_node_vec)	std::cout << "tube_push_out before short: radius=" << tpshin.radius << ", r=" << tpshin.r << ", c=" << tpshin.c << std::endl;
			
			//std::cout << "second stage reached!" << std::endl;
			
			/*
			if(row == 0)
			{
				fluid_displacements.out.front() += tank.fluid.front();
				fluid_displacements.out.back() += tank.fluid.back();
				continue;
			}
			if(row == diamension.rows) // NOTE might remove else
			{ 
				for(const Tube_FromNode& tube: tubes_from_node_vec)
				{
					const float vol = volume[tube.row][tube.col];
					fluid_addition_table[tube.row][tube.col].fluid[0] = vol;
					fluid_displacements.in[0] += vol;
				}
				continue;
			}
			*/
			
			std::sort(tubes_from_node_vec.begin(),
				tubes_from_node_vec.end(),
				compare_where_wetting_fluid_go_first);
			
			for(const Tube_FromNode& tpshin: tubes_from_node_vec)
			{
				//std::cout << "tube_push_out after sort: radius=" << tpshin.radius << ", r=" << tpshin.r << ", c=" << tpshin.c << std::endl;
				
				fluid_addition_table[tpshin.row][tpshin.col] = tank.pour_out_fluid(volume[tpshin.row][tpshin.col]);
			}
		}
	}
	
	TFluidAndDisplacement fluid_table_and_displacements
	{
		fluid_addition_table,
		fluid_displacements
	};
	
	return fluid_table_and_displacements;
}

TMns func::Integration::trimmer(TMns mnsc, const Tfloat& velocity)
{
	return mnsc;
}

TMns func::Integration::combine_fluid_additions
(
	const Tfloat& radius,
	TMns mnsc,
	const Tfloat& velocity,
	const dst::Diamension& diamension,
	const TFluid& fluid_addition_table,
	const int row_minimum_time,
	const int col_minimum_time
)
{
	for(int row = 0; row < diamension.rows; ++ row)
	{
		for(int col = 0; col < diamension.cols; ++ col)
		{
			const float vel = velocity[row][col];
			const float rad = radius[row][col];
			const std::vector<float> add_fluid_from_tank_to_tube
			{
				fluid_addition_table[row][col].blue,
				fluid_addition_table[row][col].grey
			};
			
			const bool tube_with_minimum_time =
			(
				(row == row_minimum_time) &&
				(col == col_minimum_time)
			);
			
			//std::cout << std::endl << "(" << row << ", " << col << "): ";
			
			mnsc[row][col].update(vel, rad, add_fluid_from_tank_to_tube, tube_with_minimum_time);
		}
	}
	
	return mnsc;
}

bool func::Integration::compare_where_wetting_fluid_go_first(const Tube_FromNode& first, const Tube_FromNode& second)
{
	return first.rad < second.rad;
}

void func::Integration::Tank::add_fluid(const bool type_fluid, const float vol)
{
	if(type_fluid)
	{
		fluid.grey += vol;
		grey_present = true;
		return;
	}
	fluid.blue += vol;
	blue_present = true;
}

func::Fluid func::Integration::Tank::pour_out_fluid(const float vol)
{
	Fluid fluid_result;
	
	if(!grey_present) //there is no grey
	{
		this->fluid.blue = std::max<float>(0, this->fluid.blue - vol);
		
		fluid_result.blue = vol;
		return fluid_result;
	}
	
	if(!blue_present) //there is no blue
	{
		this->fluid.grey = std::max<float>(0, this->fluid.grey - vol);
		fluid_result.grey = vol;
		return fluid_result;
	}
		
	if(vol < this->fluid.blue)
	{
		this->fluid.blue -= vol;
		fluid_result.blue = vol;
		return fluid_result;
	}
	
	fluid_result.blue = this->fluid.blue;
	this->fluid.blue = 0;
	
	fluid_result.grey = vol - fluid_result.blue;
	this->fluid.grey = std::max<float>(0, this->fluid.grey - fluid_result.grey);
	
	return fluid_result;
}

